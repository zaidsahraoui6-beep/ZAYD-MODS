package com.zaidmodz.panel;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(5, 8, 7);
    private final int green = Color.rgb(0, 255, 110);
    private LinearLayout page;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showLogin();
    }

    private TextView text(String value, int size) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextColor(green);
        t.setTextSize(size);
        t.setGravity(Gravity.CENTER);
        t.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        t.setPadding(12, 14, 12, 14);
        return t;
    }

    private LinearLayout base() {
        ScrollView scroll = new ScrollView(this);
        page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setGravity(Gravity.CENTER_HORIZONTAL);
        page.setPadding(24, 32, 24, 32);
        page.setBackgroundColor(bg);
        scroll.addView(page);
        setContentView(scroll);
        return page;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(green);
        b.setAllCaps(false);
        b.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(20, 35, 27)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 8, 0, 8);
        page.addView(b, lp);
        return b;
    }

    private void showLogin() {
        base();
        page.addView(text("ZAID MODZ", 28));
        page.addView(text("PERSONAL PANEL  •  v1.0", 13));
        page.addView(text("ENTER PASSWORD", 16));

        EditText pass = new EditText(this);
        pass.setSingleLine(true);
        pass.setHint("Password");
        pass.setHintTextColor(Color.GRAY);
        pass.setTextColor(green);
        pass.setInputType(129);
        pass.setGravity(Gravity.CENTER);
        pass.setBackgroundTintList(android.content.res.ColorStateList.valueOf(green));
        page.addView(pass, new LinearLayout.LayoutParams(-1, -2));

        button("LOGIN").setOnClickListener(v -> {
            if ("zaid_modz".contentEquals(pass.getText())) showMenu();
            else Toast.makeText(this, "Wrong password", Toast.LENGTH_SHORT).show();
        });
        page.addView(text("Offline demo • no game files changed", 11));
    }

    private void showMenu() {
        base();
        page.addView(text("ZAID MODZ", 28));
        page.addView(text("MAIN MENU", 16));
        button("1  •  Panel Info").setOnClickListener(v ->
            info("PANEL INFO", "Name: ZAID MODZ\nVersion: 1.0\nMode: Offline demo"));
        button("2  •  System Check").setOnClickListener(v ->
            info("SYSTEM CHECK", "App is running.\nThis demo does not scan or change your phone."));
        button("3  •  Display Settings").setOnClickListener(v ->
            info("DISPLAY SETTINGS", "Theme: Black / Green\nStatus: Enabled"));
        button("4  •  About").setOnClickListener(v ->
            info("ABOUT", "Personal demo panel made for learning.\nNo network access and no game modifications."));
        button("0  •  Logout").setOnClickListener(v -> showLogin());
    }

    private void info(String title, String message) {
        base();
        page.addView(text("ZAID MODZ", 26));
        page.addView(text(title, 18));
        page.addView(text(message, 15));
        button("BACK TO MENU").setOnClickListener(v -> showMenu());
    }
}
