ZAID MODZ — مشروع تطبيق أندرويد تجريبي

مهم:
- هذا مجلد مشروع Android، وليس APK جاهزًا للتثبيت.
- كلمة المرور التجريبية: zaid_modz
- التطبيق واجهة تعليمية فقط: لا يتصل بالإنترنت، ولا يغيّر ملفات الألعاب، ولا يحتوي ميزات غش.
- يلزم Android Studio أو بيئة تطوير أندرويد مناسبة لبناء APK.
- يتطلب تنزيل مكونات Android Gradle Plugin وAndroid SDK أثناء البناء.

الملفات الأساسية:
app/src/main/java/com/zaidmodz/panel/MainActivity.java
app/src/main/AndroidManifest.xml

إذا كنت تستعمل الهاتف فقط، فقد تحتاج إلى بيئة تطوير أندرويد تدعم مشاريع Gradle. لا تثبّت APK من مصادر مجهولة.
